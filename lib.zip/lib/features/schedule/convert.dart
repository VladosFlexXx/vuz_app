import 'package:html/dom.dart';
import 'package:html/parser.dart' as html;

import 'models.dart';

List<Lesson> lessonsFromHtml(String htmlText) {
  final document = html.parse(htmlText);

  final table = document.querySelector('table');
  if (table == null) return [];

  final lessons = <Lesson>[];

  String currentDay = '';
  String currentTime = '';

  final rows = table.querySelectorAll('tr');

  for (final row in rows) {
    final cells = row.querySelectorAll('td');
    if (cells.isEmpty) continue;

    int idx = 0;

    // 1️⃣ День недели (может быть не в каждой строке из-за rowspan)
    if (_looksLikeDay(cells[idx].text)) {
      currentDay = _clean(cells[idx].text);
      idx++;
    }

    // 2️⃣ Время (может быть не в каждой строке из-за rowspan)
    if (idx < cells.length && _looksLikeTime(cells[idx].text)) {
      currentTime = _clean(cells[idx].text);
      idx++;
    }

    // Если до сих пор нет дня или времени — строка мусорная
    if (currentDay.isEmpty || currentTime.isEmpty) {
      continue;
    }

    // 3️⃣ Остальные поля (обязательны)
    if (idx + 3 >= cells.length) continue;

    final subject = _clean(cells[idx].text);
    final place = _clean(cells[idx + 1].text);
    final type = _clean(cells[idx + 2].text);
    final teacher = _clean(cells[idx + 3].text);

    if (subject.isEmpty) continue;

    lessons.add(
      Lesson(
        day: currentDay,
        time: currentTime,
        subject: subject,
        place: place,
        type: type,
        teacher: teacher,
        status: LessonStatus.normal,
      ),
    );
  }

  return lessons;
}

bool _looksLikeDay(String text) {
  final t = text.toUpperCase();
  return t.contains('ПОНЕДЕЛЬНИК') ||
      t.contains('ВТОРНИК') ||
      t.contains('СРЕДА') ||
      t.contains('ЧЕТВЕРГ') ||
      t.contains('ПЯТНИЦА') ||
      t.contains('СУББОТА') ||
      t.contains('ВОСКРЕСЕНЬЕ');
}

bool _looksLikeTime(String text) {
  final t = text.trim();
  return RegExp(r'\d{1,2}[:.]\d{2}\s*[-–—]\s*\d{1,2}[:.]\d{2}').hasMatch(t);
}

String _clean(String s) {
  return s
      .replaceAll('\u00A0', ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}
