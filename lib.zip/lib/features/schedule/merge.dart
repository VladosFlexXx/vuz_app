import 'models.dart';

/// Нормализуем, чтобы ключи совпадали даже если:
/// - 12:00-13:20 vs 12.00-13.20
/// - разные дефисы: -, –, —
/// - лишние пробелы
String _normDay(String s) => s.toUpperCase().trim();

String _normTime(String s) {
  var t = s.trim();

  // разные дефисы -> обычный
  t = t.replaceAll('–', '-').replaceAll('—', '-');

  // двоеточия -> точки (чтобы всё было в одном формате)
  t = t.replaceAll(':', '.');

  // пробелы убираем
  t = t.replaceAll(RegExp(r'\s+'), '');

  // иногда попадается 12.00–13.20 без дефиса или с мусором — оставляем как есть,
  // но главное, чтобы одинаковые строки стали одинаковыми.
  return t;
}

String _key(Lesson l) => '${_normDay(l.day)}||${_normTime(l.time)}';

bool _looksCancelled(Lesson l) {
  final all = '${l.subject} ${l.type} ${l.teacher} ${l.place}'.toUpperCase();
  return all.contains('ОТМЕН');
}

bool _sameLesson(Lesson a, Lesson b) {
  return a.subject == b.subject &&
      a.place == b.place &&
      a.type == b.type &&
      a.teacher == b.teacher;
}

int _dayRank(String day) {
  const order = <String, int>{
    'ПОНЕДЕЛЬНИК': 1,
    'ВТОРНИК': 2,
    'СРЕДА': 3,
    'ЧЕТВЕРГ': 4,
    'ПЯТНИЦА': 5,
    'СУББОТА': 6,
    'ВОСКРЕСЕНЬЕ': 7,
  };
  return order[_normDay(day)] ?? 999;
}

int _timeRank(String time) {
  final t = _normTime(time);
  final start = t.split('-').first; // "12.00"
  final parts = start.split('.');
  final h = parts.isNotEmpty ? int.tryParse(parts[0]) ?? 99 : 99;
  final m = parts.length > 1 ? int.tryParse(parts[1]) ?? 99 : 99;
  return h * 100 + m;
}

/// Простейшее слияние:
/// - map по ключу (day + time) с нормализацией
/// - если в changes в какой-то колонке есть "ОТМЕНА" -> помечаем отменой
/// - если запись отличается от базовой -> помечаем changed и подменяем поля
List<Lesson> mergeSchedule({
  required List<Lesson> base,
  required List<Lesson> changes,
}) {
  final baseMap = <String, Lesson>{};
  for (final l in base) {
    baseMap[_key(l)] = l;
  }

  final outMap = Map<String, Lesson>.from(baseMap);

  for (final c in changes) {
    final k = _key(c);

    final isCancel = _looksCancelled(c);
    if (isCancel) {
      final b = outMap[k];
      if (b != null) {
        outMap[k] = Lesson(
          day: b.day,
          time: b.time,
          subject: b.subject,
          place: b.place,
          type: b.type,
          teacher: b.teacher,
          status: LessonStatus.cancelled,
        );
      } else {
        outMap[k] = Lesson(
          day: c.day,
          time: c.time,
          subject: c.subject,
          place: c.place,
          type: c.type,
          teacher: c.teacher,
          status: LessonStatus.cancelled,
        );
      }
      continue;
    }

    final b = outMap[k];
    if (b != null) {
      final same = _sameLesson(b, c);
      outMap[k] = Lesson(
        day: c.day,
        time: c.time,
        subject: c.subject.isNotEmpty ? c.subject : b.subject,
        place: c.place.isNotEmpty ? c.place : b.place,
        type: c.type.isNotEmpty ? c.type : b.type,
        teacher: c.teacher.isNotEmpty ? c.teacher : b.teacher,
        status: same ? b.status : LessonStatus.changed,
      );
    } else {
      outMap[k] = Lesson(
        day: c.day,
        time: c.time,
        subject: c.subject,
        place: c.place,
        type: c.type,
        teacher: c.teacher,
        status: LessonStatus.changed,
      );
    }
  }

  final out = outMap.values.toList();

  // сортировка стабильная по нормализованным значениям
  out.sort((a, b) {
    final d = _dayRank(a.day).compareTo(_dayRank(b.day));
    if (d != 0) return d;
    return _timeRank(a.time).compareTo(_timeRank(b.time));
  });

  return out;
}
