import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'package:vuz_app/core/auth/session_manager.dart';
import 'package:vuz_app/core/network/eios_client.dart';
import 'package:vuz_app/features/auth/login_webview.dart';

import '../notifications/notification_service.dart';
import '../schedule/schedule_repository.dart';
import 'tab_dashboard.dart';
import 'tab_grades.dart';
import 'tab_profile.dart';
import 'tab_schedule.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _storage = FlutterSecureStorage();

  late final VoidCallback _sessionListener;

  Future<void> _handleSessionExpired() async {
    // чистим куки
    await _storage.delete(key: 'cookie_header');
    EiosClient.instance.invalidateCookieCache();

    // сбрасываем флаг, чтобы не зациклилось
    SessionManager.instance.reset();

    if (!mounted) return;

    // уводим на логин и очищаем стек
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginWebViewScreen()),
      (_) => false,
    );
  }

  int _index = 0;

  void _navigateTo(int i) => setState(() => _index = i);

  late final List<Widget> _pages = [
    DashboardTab(onNavigate: _navigateTo),
    const ScheduleTab(),
    const GradesTab(),
    const ProfileTab(),
  ];

  final _notif = NotificationService.instance;

  @override
  void initState() {
    super.initState();

    // кеш покажется сразу (если есть), потом обновится актуальным
    ScheduleRepository.instance.initAndRefresh();

    // слушаем переход по пушу
    _notif.action.addListener(_onNotificationAction);

    // ✅ слушаем "сессия умерла"
    _sessionListener = () {
      if (SessionManager.instance.expired.value) {
        _handleSessionExpired();
      }
    };
    SessionManager.instance.expired.addListener(_sessionListener);
  }

  void _onNotificationAction() {
    final act = _notif.action.value;
    if (act == null) return;

    if (act.target == AppNavTarget.schedule) {
      // вкладка расписания = индекс 1
      _navigateTo(1);
      // если хочешь — можно тут же сделать refresh:
      ScheduleRepository.instance.refresh();
    }

    // чтобы одно и то же событие не срабатывало повторно
    _notif.action.value = null;
  }

  @override
  void dispose() {
    _notif.action.removeListener(_onNotificationAction);

    // ✅ отписка от "сессия умерла"
    SessionManager.instance.expired.removeListener(_sessionListener);

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _index,
          children: _pages,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _index,
        onTap: _navigateTo,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home),
            label: 'Главная',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            activeIcon: Icon(Icons.calendar_today),
            label: 'Расписание',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school_outlined),
            activeIcon: Icon(Icons.school),
            label: 'Оценки',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: 'Профиль',
          ),
        ],
      ),
    );
  }
}
