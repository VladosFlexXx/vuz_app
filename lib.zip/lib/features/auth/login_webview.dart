import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:vuz_app/core/network/eios_client.dart';

import '../home/home_screen.dart';

class LoginWebViewScreen extends StatefulWidget {
  const LoginWebViewScreen({super.key});

  @override
  State<LoginWebViewScreen> createState() => _LoginWebViewScreenState();
}

class _LoginWebViewScreenState extends State<LoginWebViewScreen> {
  static const _storage = FlutterSecureStorage();

  InAppWebViewController? _controller;
  double _progress = 0;

  bool _didEnterHome = false;
  bool _savingCookies = false;

  // Стартуем сразу с "my" — если не залогинен, он редиректнет на логин
  static const String _startUrl = 'https://eos.imes.su/my/';

  Future<void> _goToApp() async {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  Future<void> _saveCookiesForDomain() async {
    if (_savingCookies) return;
    _savingCookies = true;

    try {
      // Собираем cookies именно для домена eos.imes.su
      final cookies = await CookieManager.instance().getCookies(
        url: WebUri('https://eos.imes.su/'),
      );

      // Склеиваем в стандартный Cookie header: "k1=v1; k2=v2"
      final header = cookies.map((c) => '${c.name}=${c.value}').join('; ');

      if (header.trim().isNotEmpty) {
        await _storage.write(key: 'cookie_header', value: header);
        EiosClient.instance.invalidateCookieCache();
        debugPrint('COOKIE_HEADER saved, len=${header.length}');
      } else {
        debugPrint('COOKIE_HEADER empty (not saved)');
      }
    } catch (e) {
      debugPrint('SAVE COOKIES ERROR: $e');
    } finally {
      _savingCookies = false;
    }
  }

  Future<void> _maybeDetectLoggedIn(String? url) async {
    if (_didEnterHome) return;

    final u = (url ?? '').toLowerCase();

    // 1) По URL: Moodle обычно после логина ведёт на /my/ или /user/ и т.п.
    final urlLooksLoggedIn =
        u.contains('eos.imes.su/my') || u.contains('eos.imes.su/user/');

    // 2) По DOM: ищем "Личный кабинет" или что-то характерное
    bool domLooksLoggedIn = false;
    try {
      if (_controller != null) {
        final js = """
          (function() {
            const text = (document.body && document.body.innerText) ? document.body.innerText : '';
            const t = text.toUpperCase();
            if (t.includes('ЛИЧНЫЙ КАБИНЕТ')) return true;
            if (t.includes('ВЫХОД') || t.includes('LOGOUT')) return true;
            return false;
          })();
        """;
        final res = await _controller!.evaluateJavascript(source: js);
        domLooksLoggedIn = (res == true);
      }
    } catch (_) {
      // игнор
    }

    if (urlLooksLoggedIn || domLooksLoggedIn) {
      _didEnterHome = true;

      // сохраняем cookies (чтобы нативные репозитории могли ходить через http)
      await _saveCookiesForDomain();

      // и уходим в UI
      await _goToApp();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Вход в ЭИОС'),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            icon: const Icon(Icons.refresh),
            onPressed: () => _controller?.reload(),
          ),
          TextButton(
            onPressed: () async {
              // На всякий случай сохраним cookies и пустим в UI вручную
              await _saveCookiesForDomain();
              await _goToApp();
            },
            child: const Text('В приложение'),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_progress < 1)
            LinearProgressIndicator(value: _progress, minHeight: 3),
          Expanded(
            child: InAppWebView(
              initialUrlRequest: URLRequest(url: WebUri(_startUrl)),
              initialSettings: InAppWebViewSettings(
                javaScriptEnabled: true,
                domStorageEnabled: true,
                databaseEnabled: true,
                thirdPartyCookiesEnabled: true,
                mixedContentMode: MixedContentMode.MIXED_CONTENT_ALWAYS_ALLOW,
                useShouldOverrideUrlLoading: true,
                supportZoom: true,
                userAgent:
                    'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
              ),
              onWebViewCreated: (c) => _controller = c,
              onProgressChanged: (_, p) => setState(() => _progress = p / 100),
              onLoadStop: (controller, url) async {
                await _maybeDetectLoggedIn(url?.toString());
              },
              shouldOverrideUrlLoading: (controller, action) async {
                final u = action.request.url?.toString();
                // каждый переход — шанс понять, что мы уже залогинились
                await _maybeDetectLoggedIn(u);
                return NavigationActionPolicy.ALLOW;
              },
            ),
          ),
        ],
      ),
    );
  }
}
